import mongoose, { ObjectId, Schema } from "mongoose";

export default mongoose.model(
  "Comment",
  new Schema(
    {
      _id: { type: ObjectId },
      rate: {
        type: number,
        required: true,
      },
      text: {
        type: String,
        required: true,
      },
      author: {
        type: String,
        required: true,
      },
    },
    {
      timestamps: true,
    }
  )
);
