import mongoose, { Schema } from "mongoose";

const productSchema = new Schema(
  {
    name: {
      type: String,
      required: [true, "Name is require"],
      unique: true,
    },
    price: {
      type: Number,
      min: [0, "Price must lest than 0"],
      required: [true, "Price is require"],
    },
    description: {
      type: String,
      required: true,
    },
    images: [
      {
        _id: { type: mongoose.Schema.Types.ObjectId, ref: "Image" },
        url: { type: String, required: true },
        caption: { type: String, required: true },
      },
    ],
    comments: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Comment",
      },
    ],
    category: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Categoty",
    },
  },
  {
    timestamps: true,
  }
);

const Products = mongoose.model("Products", productSchema);
export default Products;
