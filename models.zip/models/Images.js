import mongoose, { ObjectId, Schema } from "mongoose";

export default mongoose.model(
  "Image",
  new Schema(
    {
      _id: { type: ObjectId },
      path: {
        type: String,
        required: true,
      },
      url: {
        type: String,
        required: true,
      },
      caption: {
        type: String,
        required: true,
      },
    },
    {
      timestamps: true,
    }
  )
);
